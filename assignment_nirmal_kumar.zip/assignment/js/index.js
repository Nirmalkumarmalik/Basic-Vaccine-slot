let userInfo = {};

let inputs = document.querySelectorAll("input");
for(const input of inputs) {
	input.addEventListener('input',userHandler);
}
document.querySelector('textarea').addEventListener('input',userHandler);
function userHandler(event) {
	userInfo[event.target.name] = event.target.value;
	console.log(userInfo);
}
document.querySelector('form').addEventListener('submit',submitData)
function submitData() {
	let users = localStorage.getItem('users') ? JSON.parse(localStorage.getItem('users')) : [];
	users.push(userInfo);
	localStorage.setItem('users',JSON.stringify(users));
}